---
layout: page
title: Results
---

**Findings**

What were the outcomes of your analyses?
What is your interpretation of those findings?

**Deliverables**

What artifacts or outputs did you produce?
How will these deliverables be used? 

**Outcomes**

How have your stakeholders responded to your deliverables? 
What impact has your project had, or do you anticipate it having? 
